# Husvakur Static Website

A pure static HTML/CSS/JavaScript version of Husvakur, ready for Cloudflare Pages.

## Deploy from iPhone

1. Create a GitHub repository named `husvakur`.
2. Upload everything inside the `public` folder to the repository.
3. In Cloudflare, open **Workers & Pages → Create → Pages → Connect to Git**.
4. Select the GitHub repository.
5. Framework preset: **None**.
6. Build command: leave empty.
7. Build output directory: `public` (if the repository contains the `public` folder).
8. Deploy.

This version is a frontend only. The video picker works, but files are not uploaded to a server yet. Add R2/Worker upload functionality when you're ready.
